

--
-- Data for Name: systems; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.systems (name, value) FROM stdin;
AdvancedPermissionsMigrationComplete	true
AsymmetricSigningKey	{"ecdsa_key":{"curve":"P-256","x":43639296303390645963367212006175254346213184632440984115159104432957071480855,"y":34269321799431462309178171636947969594828046152881688879656064556598096223605,"d":26796794008185008922659668526770856981564548372723868019175319696367209600117}}
DiagnosticId	89982adb1cab27cae5e59e4db5
EmojisPermissionsMigrationComplete	true
InstallationDate	1535837373735
Version	5.2.0
migration_advanced_permissions_phase_2	true
\.
