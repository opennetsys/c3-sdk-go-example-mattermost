

--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teams (id, createat, updateat, deleteat, displayname, name, description, email, type, companyname, alloweddomains, inviteid, allowopeninvite, lastteamiconupdate, schemeid) FROM stdin;
89982adb1cab27cae5e59e4db5	3	3	0	c3	c3		ahanna@alumni.mines.edu	O			6eee2ef43121c3fcf6638a10e7	f	0	\N
\.
