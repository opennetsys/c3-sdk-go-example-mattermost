

--
-- Data for Name: emoji; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.emoji (id, createat, updateat, deleteat, creatorid, name) FROM stdin;
\.
