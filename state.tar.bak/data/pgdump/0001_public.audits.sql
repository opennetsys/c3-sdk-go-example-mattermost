
--
-- Data for Name: audits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audits (id, createat, userid, action, extrainfo, ipaddress, sessionid) FROM stdin;
681aafca6dc296f9ddda43fef5	22	cb093fcd2fc817e5565430538e	/api/v4/users/login	attempt - login_id=	::1	
6a0562d783ed3f6960ac7ce000	177	cb093fcd2fc817e5565430538e	/api/v4/users/cb093fcd2fc817e5565430538e/image		::1	91a38123ecb3d85924afcbbf22
6c5cfe300e3b0e940a0c1603f3	124	cb093fcd2fc817e5565430538e	/api/v4/users/me/patch		::1	91a38123ecb3d85924afcbbf22
7dc82c031cba30d1debcaa90ad	29	cb093fcd2fc817e5565430538e	/api/v4/users/login	success	::1	
cda4e86ac79e7b07a4569a9c02	24	cb093fcd2fc817e5565430538e	/api/v4/users/login	authenticated	::1	
\.
