

--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.posts (id, createat, updateat, editat, deleteat, ispinned, userid, channelid, rootid, parentid, originalid, message, type, props, hashtags, filenames, fileids, hasreactions) FROM stdin;
0b05f1a24a02d56220bb12ed16	7	7	0	0	f	cb093fcd2fc817e5565430538e	59cc8420f8f2904b1daf41ebff				telefonica joined the team.	system_join_team	{"username":"telefonica"}		[]	[]	f
8e87f7708d03dc74063f6c9504	10	10	0	0	f	cb093fcd2fc817e5565430538e	59cc8420f8f2904b1daf41ebff				hello, world!		{}		[]	[]	f
91a38123ecb3d85924afcbbf22	2	2	0	0	f	cb093fcd2fc817e5565430538e	59cc8420f8f2904b1daf41ebff				test		{}		[]	[]	f
cb093fcd2fc817e5565430538e	5	5	0	0	f	cb093fcd2fc817e5565430538e	59cc8420f8f2904b1daf41ebff				foo		{}		[]	[]	f
e8b5d82cb9d28dda06059417e4	9	9	0	0	f	cb093fcd2fc817e5565430538e	3e841b6443a702d3e06b0492e9				telefonica joined the channel.	system_join_channel	{"username":"telefonica"}		[]	[]	f
\.
