

--
-- Data for Name: channelmemberhistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.channelmemberhistory (channelid, userid, jointime, leavetime) FROM stdin;
3e841b6443a702d3e06b0492e9	cb093fcd2fc817e5565430538e	81	\N
59cc8420f8f2904b1daf41ebff	cb093fcd2fc817e5565430538e	77	\N
cb093fcd2fc817e5565430538e	cb093fcd2fc817e5565430538e	93	\N
cb093fcd2fc817e5565430538e	cb093fcd2fc817e5565430538e	94	\N
\.
