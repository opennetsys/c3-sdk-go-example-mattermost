

--
-- Data for Name: useraccesstokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.useraccesstokens (id, token, userid, description, isactive) FROM stdin;
\.
