

--
-- Data for Name: outgoingwebhooks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.outgoingwebhooks (id, token, createat, updateat, deleteat, creatorid, channelid, teamid, triggerwords, triggerwhen, callbackurls, displayname, description, contenttype, username, iconurl) FROM stdin;
\.
