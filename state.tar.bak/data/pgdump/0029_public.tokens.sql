

--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tokens (token, createat, type, extra) FROM stdin;
b75b9d7cf4a7f9958485928b8fa83aeed691cee2e25c4b63c120ece2222b21f0	19	verify_email	cb093fcd2fc817e5565430538e
\.
