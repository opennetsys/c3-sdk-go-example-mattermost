

--
-- Data for Name: reactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reactions (userid, postid, emojiname, createat) FROM stdin;
\.
