

--
-- Data for Name: pluginkeyvaluestore; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pluginkeyvaluestore (pluginid, pkey, pvalue) FROM stdin;
\.
