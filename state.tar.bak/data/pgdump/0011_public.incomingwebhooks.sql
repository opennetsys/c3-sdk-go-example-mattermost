

--
-- Data for Name: incomingwebhooks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.incomingwebhooks (id, createat, updateat, deleteat, userid, channelid, teamid, displayname, description, username, iconurl, channellocked) FROM stdin;
\.
