

--
-- Data for Name: teammembers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teammembers (teamid, userid, roles, deleteat, schemeuser, schemeadmin) FROM stdin;
89982adb1cab27cae5e59e4db5	cb093fcd2fc817e5565430538e		0	t	t
\.
