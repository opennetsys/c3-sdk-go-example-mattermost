

--
-- Data for Name: preferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.preferences (userid, category, name, value) FROM stdin;
cb093fcd2fc817e5565430538e	channel_approximate_view_time		1536921567964
cb093fcd2fc817e5565430538e	channel_open_time	cb093fcd2fc817e5565430538e	1536176149429
cb093fcd2fc817e5565430538e	direct_channel_show	cb093fcd2fc817e5565430538e	true
cb093fcd2fc817e5565430538e	tutorial_step	cb093fcd2fc817e5565430538e	999
\.
