

--
-- Data for Name: channels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.channels (id, createat, updateat, deleteat, teamid, type, displayname, name, header, purpose, lastpostat, totalmsgcount, extraupdateat, creatorid, schemeid) FROM stdin;
3e841b6443a702d3e06b0492e9	5	5	0	89982adb1cab27cae5e59e4db5	O	Off-Topic	off-topic			9	0	0		\N
59cc8420f8f2904b1daf41ebff	4	4	0	89982adb1cab27cae5e59e4db5	O	Town Square	town-square			2	3	0		\N
cb093fcd2fc817e5565430538e	1	1	0		D		cb093fcd2fc817e5565430538e__cb093fcd2fc817e5565430538e			0	0	0		\N
\.
