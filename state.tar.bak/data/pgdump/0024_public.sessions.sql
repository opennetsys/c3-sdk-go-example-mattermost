

--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, token, createat, expiresat, lastactivityat, userid, deviceid, roles, isoauth, props) FROM stdin;
91a38123ecb3d85924afcbbf22	2452429df325a0c3a5516d3fb3	2	2592000026	2	cb093fcd2fc817e5565430538e		system_admin system_user	f	{"browser":"Chrome/68.0.3440","csrf":"516e23a442549b61ccecd2c677","os":"Windows 10","platform":"Windows"}
\.
