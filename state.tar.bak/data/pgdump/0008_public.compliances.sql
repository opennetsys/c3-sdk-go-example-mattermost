

--
-- Data for Name: compliances; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.compliances (id, createat, userid, status, count, "desc", type, startat, endat, keywords, emails) FROM stdin;
\.
