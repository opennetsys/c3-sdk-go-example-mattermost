

--
-- Data for Name: oauthaccessdata; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.oauthaccessdata (clientid, userid, token, refreshtoken, redirecturi, expiresat, scope) FROM stdin;
\.
