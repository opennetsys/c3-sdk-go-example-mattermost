

--
-- Data for Name: pluginkeyvaluestore; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.pluginkeyvaluestore (pluginid, pkey, pvalue, expireat) FROM stdin;
\.
