

--
-- Data for Name: useraccesstokens; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.useraccesstokens (id, token, userid, description, isactive) FROM stdin;
\.
