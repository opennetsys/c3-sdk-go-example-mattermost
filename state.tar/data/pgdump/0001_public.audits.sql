
--
-- Data for Name: audits; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.audits (id, createat, userid, action, extrainfo, ipaddress, sessionid) FROM stdin;
56a56d124891a02601c1921ff2	83	6eee2ef43121c3fcf6638a10e7	/api/v4/users/login	attempt - login_id= session_user=cb093fcd2fc817e5565430538e	::1	2452429df325a0c3a5516d3fb3
b02063ee6175299e62825aa117	88	6eee2ef43121c3fcf6638a10e7	/api/v4/users/login	success session_user=cb093fcd2fc817e5565430538e	::1	2452429df325a0c3a5516d3fb3
bf6123349c5b03f675e58ed217	85	6eee2ef43121c3fcf6638a10e7	/api/v4/users/login	authenticated session_user=cb093fcd2fc817e5565430538e	::1	2452429df325a0c3a5516d3fb3
\.
