
--
-- Data for Name: audits; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.audits (id, createat, userid, action, extrainfo, ipaddress, sessionid) FROM stdin;
00679dc6c208c0fa1be7601afe	51	cb093fcd2fc817e5565430538e	/api/v4/users/login	success	::1	
26aac7c94509c7942be6f6ef44	46	cb093fcd2fc817e5565430538e	/api/v4/users/login	attempt - login_id=	::1	
cd97e861b148eaf076b22cb331	48	cb093fcd2fc817e5565430538e	/api/v4/users/login	authenticated	::1	
\.
