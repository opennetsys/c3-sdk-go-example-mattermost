
--
-- Data for Name: audits; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.audits (id, createat, userid, action, extrainfo, ipaddress, sessionid) FROM stdin;
2f5d519016be35fc62a535495c	58	cb093fcd2fc817e5565430538e	/api/v4/users/login	success	::1	
45370279918ca4368c3cf23050	55	cb093fcd2fc817e5565430538e	/api/v4/users/login	authenticated	::1	
c2ad756188e8c4bdc0b50ff5d4	53	cb093fcd2fc817e5565430538e	/api/v4/users/login	attempt - login_id=	::1	
dc98de95127275b174e6766f60	41		/api/v4/users/logout		::1	
\.
