
--
-- Data for Name: audits; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.audits (id, createat, userid, action, extrainfo, ipaddress, sessionid) FROM stdin;
0607ffe0696000853db1c500e6	16	cb093fcd2fc817e5565430538e	/api/v4/users/login	authenticated	::1	
181e9c1dc34687ea1ed907c756	40	cb093fcd2fc817e5565430538e	/api/v4/users/login	authenticated	::1	
2089b861b21fa23b9ecb8d521f	28		/api/v4/users/logout		::1	
3s6aeco3f7d7feh6gm11bg6omc	1541465561017		/api/v4/users/login	failure - login_id=ahanna@alumni.mines.edu	::1	
406d7ab58c9d240c56e6862cd2	23		/api/v4/users/logout		::1	
5ce5u3wzxffr5kc4hpz9c9gode	1541465548417		/api/v4/users/logout		::1	
5fadd539ca911e368c838c0249	14	cb093fcd2fc817e5565430538e	/api/v4/users/login	attempt - login_id=	::1	
76edc858c8f09e82f91c52514e	45		/api/v4/users/login	failure - login_id=ahanna@alumni.mines.edu	::1	
842170c56367ec75dcc49d19ec	50	cb093fcd2fc817e5565430538e	/api/v4/users/login	authenticated	::1	
8a57bf2963e1106513d88fd278	43		/api/v4/users/login	attempt - login_id=ahanna@alumni.mines.edu	::1	
b75b9d7cf4a7f9958485928b8f	19	cb093fcd2fc817e5565430538e	/api/v4/users/login	success	::1	
c2ad756188e8c4bdc0b50ff5d4	53	cb093fcd2fc817e5565430538e	/api/v4/users/login	success	::1	
cd97e861b148eaf076b22cb331	48		/api/v4/users/login	attempt - login_id=ahanna@alumni.mines.edu	::1	
d4rwdo7g87fx7q7iy8f8nqm7ey	1541465548513		/api/v4/users/logout		::1	
dr8731gm1ibd9p9rb6omzu58nr	1541465560884		/api/v4/users/login	attempt - login_id=ahanna@alumni.mines.edu	::1	
f414371bd4af71ceb83fd05c22	38		/api/v4/users/login	attempt - login_id=ahanna@alumni.mines.edu	::1	
r65z8x88rpf5uqmdc4h85yqgao	1541466224415		/api/v4/users/logout		::1	
ubd9s8skkjf79duxa9c31gopbo	1541466224473		/api/v4/users/logout		::1	
\.
