

--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.tokens (token, createat, type, extra) FROM stdin;
8a57bf2963e1106513d88fd27864b918ec2b4c7abf031ce3abc5a460b1ded99d	43	verify_email	cb093fcd2fc817e5565430538e
\.
