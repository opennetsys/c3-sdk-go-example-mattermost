

--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.tokens (token, createat, type, extra) FROM stdin;
91b7ffd98f947ac951759c5cc46b6e61023b12421de74f615b2e89c5381c8add	80	verify_email	6eee2ef43121c3fcf6638a10e7
\.
