

--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.tokens (token, createat, type, extra) FROM stdin;
842170c56367ec75dcc49d19ec7c33e01a22e099827fbf9997dc9648f227e75d	50	verify_email	cb093fcd2fc817e5565430538e
\.
