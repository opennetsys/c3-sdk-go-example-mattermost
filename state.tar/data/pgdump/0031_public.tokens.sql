

--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.tokens (token, createat, type, extra) FROM stdin;
8e87f7708d03dc74063f6c95043f95e6f8fe457720b3317c220b492fdb776ed8	11	verify_email	cb093fcd2fc817e5565430538e
\.
