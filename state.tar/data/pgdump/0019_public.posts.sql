

--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.posts (id, createat, updateat, editat, deleteat, ispinned, userid, channelid, rootid, parentid, originalid, message, type, props, hashtags, filenames, fileids, hasreactions) FROM stdin;
59cc8420f8f2904b1daf41ebff	43	43	0	0	f	cb093fcd2fc817e5565430538e	89982adb1cab27cae5e59e4db5				telefonica joined the channel.	system_join_channel	{"username":"telefonica"}		[]	[]	f
6eee2ef43121c3fcf6638a10e7	41	41	0	0	f	cb093fcd2fc817e5565430538e	2452429df325a0c3a5516d3fb3				telefonica joined the team.	system_join_team	{"username":"telefonica"}		[]	[]	f
91a38123ecb3d85924afcbbf22	53	53	0	0	f	cb093fcd2fc817e5565430538e	2452429df325a0c3a5516d3fb3				bar		{}		[]	[]	f
cb093fcd2fc817e5565430538e	43	43	0	0	f	cb093fcd2fc817e5565430538e	2452429df325a0c3a5516d3fb3				foo		{}		[]	[]	f
\.
