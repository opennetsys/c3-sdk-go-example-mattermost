

--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.posts (id, createat, updateat, editat, deleteat, ispinned, userid, channelid, rootid, parentid, originalid, message, type, props, hashtags, filenames, fileids, hasreactions) FROM stdin;
8e87f7708d03dc74063f6c9504	35	35	0	0	f	cb093fcd2fc817e5565430538e	0b05f1a24a02d56220bb12ed16				telefonica joined the channel.	system_join_channel	{"username":"telefonica"}		[]	[]	f
cb093fcd2fc817e5565430538e	13	13	0	0	f	cb093fcd2fc817e5565430538e	3e841b6443a702d3e06b0492e9				goodbye!		{}		[]	[]	f
e8b5d82cb9d28dda06059417e4	33	33	0	0	f	cb093fcd2fc817e5565430538e	3e841b6443a702d3e06b0492e9				telefonica joined the team.	system_join_team	{"username":"telefonica"}		[]	[]	f
e8d8288877d81d5b41be877161	59	59	0	0	f	cb093fcd2fc817e5565430538e	3e841b6443a702d3e06b0492e9				hello!		{}		[]	[]	f
\.
