

--
-- Data for Name: preferences; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.preferences (userid, category, name, value) FROM stdin;
6eee2ef43121c3fcf6638a10e7	tutorial_step	6eee2ef43121c3fcf6638a10e7	0
\.
