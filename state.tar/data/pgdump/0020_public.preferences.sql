

--
-- Data for Name: preferences; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.preferences (userid, category, name, value) FROM stdin;
cb093fcd2fc817e5565430538e	channel_approximate_view_time		1542415299708
cb093fcd2fc817e5565430538e	tutorial_step	cb093fcd2fc817e5565430538e	999
\.
