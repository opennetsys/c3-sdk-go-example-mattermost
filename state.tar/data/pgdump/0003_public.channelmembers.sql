

--
-- Data for Name: channelmembers; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.channelmembers (channelid, userid, roles, lastviewedat, msgcount, mentioncount, notifyprops, lastupdateat, schemeuser, schemeadmin) FROM stdin;
0b05f1a24a02d56220bb12ed16	cb093fcd2fc817e5565430538e		0	0	0	{"desktop":"default","email":"default","mark_unread":"all","push":"default"}	34	t	t
3e841b6443a702d3e06b0492e9	cb093fcd2fc817e5565430538e		59	2	0	{"desktop":"default","email":"default","mark_unread":"all","push":"default"}	59	t	t
\.
