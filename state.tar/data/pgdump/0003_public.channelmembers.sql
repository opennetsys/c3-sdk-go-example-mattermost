

--
-- Data for Name: channelmembers; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.channelmembers (channelid, userid, roles, lastviewedat, msgcount, mentioncount, notifyprops, lastupdateat, schemeuser, schemeadmin) FROM stdin;
2452429df325a0c3a5516d3fb3	cb093fcd2fc817e5565430538e		53	2	0	{"desktop":"default","email":"default","mark_unread":"all","push":"default"}	53	t	t
89982adb1cab27cae5e59e4db5	cb093fcd2fc817e5565430538e		0	0	0	{"desktop":"default","email":"default","mark_unread":"all","push":"default"}	42	t	t
cb093fcd2fc817e5565430538e	cb093fcd2fc817e5565430538e		0	0	0	{"desktop":"default","email":"default","mark_unread":"all","push":"default"}	0	t	t
\.
