

--
-- Data for Name: channelmembers; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.channelmembers (channelid, userid, roles, lastviewedat, msgcount, mentioncount, notifyprops, lastupdateat, schemeuser, schemeadmin) FROM stdin;
\.
