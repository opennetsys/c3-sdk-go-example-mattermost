

--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.sessions (id, token, createat, expiresat, lastactivityat, userid, deviceid, roles, isoauth, props) FROM stdin;
3e841b6443a702d3e06b0492e9	0b05f1a24a02d56220bb12ed16	18	2592000017	18	6eee2ef43121c3fcf6638a10e7		system_admin system_user	f	{"browser":"Chrome/71.0.3578","csrf":"59cc8420f8f2904b1daf41ebff","os":"Linux","platform":"Linux"}
\.
