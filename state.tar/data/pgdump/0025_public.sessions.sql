

--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.sessions (id, token, createat, expiresat, lastactivityat, userid, deviceid, roles, isoauth, props) FROM stdin;
2452429df325a0c3a5516d3fb3	89982adb1cab27cae5e59e4db5	3	2592000002	3	cb093fcd2fc817e5565430538e		system_admin system_user	f	{"browser":"Chrome/70.0.3538","csrf":"91a38123ecb3d85924afcbbf22","os":"Linux","platform":"Linux"}
\.
