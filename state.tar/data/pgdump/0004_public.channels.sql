

--
-- Data for Name: channels; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.channels (id, createat, updateat, deleteat, teamid, type, displayname, name, header, purpose, lastpostat, totalmsgcount, extraupdateat, creatorid, schemeid) FROM stdin;
0b05f1a24a02d56220bb12ed16	31	31	0	6eee2ef43121c3fcf6638a10e7	O	Off-Topic	off-topic			35	0	0		\N
3e841b6443a702d3e06b0492e9	30	30	0	6eee2ef43121c3fcf6638a10e7	O	Town Square	town-square			59	1	0		\N
\.
