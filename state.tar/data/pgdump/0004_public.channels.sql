

--
-- Data for Name: channels; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.channels (id, createat, updateat, deleteat, teamid, type, displayname, name, header, purpose, lastpostat, totalmsgcount, extraupdateat, creatorid, schemeid) FROM stdin;
2452429df325a0c3a5516d3fb3	38	38	0	cb093fcd2fc817e5565430538e	O	Town Square	town-square			53	2	0		\N
89982adb1cab27cae5e59e4db5	39	39	0	cb093fcd2fc817e5565430538e	O	Off-Topic	off-topic			43	0	0		\N
cb093fcd2fc817e5565430538e	29	29	0	cb093fcd2fc817e5565430538e	O	test	test			0	0	0	cb093fcd2fc817e5565430538e	\N
\.
