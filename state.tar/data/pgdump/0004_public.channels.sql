

--
-- Data for Name: channels; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.channels (id, createat, updateat, deleteat, teamid, type, displayname, name, header, purpose, lastpostat, totalmsgcount, extraupdateat, creatorid, schemeid) FROM stdin;
\.
