

--
-- Data for Name: channelmemberhistory; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.channelmemberhistory (channelid, userid, jointime, leavetime) FROM stdin;
\.
