

--
-- Data for Name: channelmemberhistory; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.channelmemberhistory (channelid, userid, jointime, leavetime) FROM stdin;
0b05f1a24a02d56220bb12ed16	cb093fcd2fc817e5565430538e	66	\N
3e841b6443a702d3e06b0492e9	cb093fcd2fc817e5565430538e	62	\N
\.
