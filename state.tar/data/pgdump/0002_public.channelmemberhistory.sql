

--
-- Data for Name: channelmemberhistory; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.channelmemberhistory (channelid, userid, jointime, leavetime) FROM stdin;
2452429df325a0c3a5516d3fb3	cb093fcd2fc817e5565430538e	57	\N
89982adb1cab27cae5e59e4db5	cb093fcd2fc817e5565430538e	61	\N
\.
