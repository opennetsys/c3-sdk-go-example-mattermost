

--
-- Data for Name: oauthapps; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.oauthapps (id, creatorid, createat, updateat, clientsecret, name, description, iconurl, callbackurls, homepage, istrusted) FROM stdin;
\.
