

--
-- Data for Name: termsofservice; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.termsofservice (id, createat, userid, text) FROM stdin;
\.
