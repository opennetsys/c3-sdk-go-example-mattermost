

--
-- Data for Name: fileinfo; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.fileinfo (id, creatorid, postid, createat, updateat, deleteat, path, thumbnailpath, previewpath, name, extension, size, mimetype, width, height, haspreviewimage) FROM stdin;
\.
