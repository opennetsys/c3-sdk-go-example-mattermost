

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.users (id, createat, updateat, deleteat, username, password, authdata, authservice, email, emailverified, nickname, firstname, lastname, "position", roles, allowmarketing, props, notifyprops, lastpasswordupdate, lastpictureupdate, failedattempts, locale, timezone, mfaactive, mfasecret, acceptedtermsofserviceid) FROM stdin;
6eee2ef43121c3fcf6638a10e7	15	15	0	telefonica	40f158eff0b50575ef6c7d5f72281e9dcef3c19f75dedf204f7c00aa7e42329d	\N		ahanna@alumni.mines.edu	f					system_admin system_user	t	{}	{"channel":"true","comments":"never","desktop":"mention","desktop_sound":"true","email":"true","first_name":"false","mention_keys":"telefonica,@telefonica","push":"mention","push_status":"away"}	15	0	0	en	{"automaticTimezone":"","manualTimezone":"","useAutomaticTimezone":"true"}	f		
\.
