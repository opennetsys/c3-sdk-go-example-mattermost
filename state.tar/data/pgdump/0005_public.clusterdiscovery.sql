

--
-- Data for Name: clusterdiscovery; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.clusterdiscovery (id, type, clustername, hostname, gossipport, port, createat, lastpingat) FROM stdin;
\.
