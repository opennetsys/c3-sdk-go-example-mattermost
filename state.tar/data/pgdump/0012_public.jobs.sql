

--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.jobs (id, type, priority, createat, startat, lastactivityat, status, progress, data) FROM stdin;
85b3od1h7jbp8xffkh8p6ct3sc	migrations	0	1541463415241	1541463428850	1541463429142	success	0	{"last_done":"{\\"current_table\\":\\"ChannelMembers\\",\\"last_team_id\\":\\"00000000000000000000000000\\",\\"last_channel_id\\":\\"00000000000000000000000000\\",\\"last_user\\":\\"00000000000000000000000000\\"}","migration_key":"migration_advanced_permissions_phase_2"}
\.
