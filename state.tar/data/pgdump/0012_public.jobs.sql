

--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.jobs (id, type, priority, createat, startat, lastactivityat, status, progress, data) FROM stdin;
\.
