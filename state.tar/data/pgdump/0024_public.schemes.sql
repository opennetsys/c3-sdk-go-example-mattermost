

--
-- Data for Name: schemes; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.schemes (id, name, displayname, description, createat, updateat, deleteat, scope, defaultteamadminrole, defaultteamuserrole, defaultchanneladminrole, defaultchanneluserrole) FROM stdin;
\.
