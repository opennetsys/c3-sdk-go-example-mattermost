

--
-- Data for Name: commands; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.commands (id, token, createat, updateat, deleteat, creatorid, teamid, trigger, method, username, iconurl, autocomplete, autocompletedesc, autocompletehint, displayname, description, url) FROM stdin;
\.
