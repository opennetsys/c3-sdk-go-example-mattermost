

--
-- Data for Name: publicchannels; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.publicchannels (id, deleteat, teamid, displayname, name, header, purpose) FROM stdin;
2452429df325a0c3a5516d3fb3	0	cb093fcd2fc817e5565430538e	Town Square	town-square		
89982adb1cab27cae5e59e4db5	0	cb093fcd2fc817e5565430538e	Off-Topic	off-topic		
\.
