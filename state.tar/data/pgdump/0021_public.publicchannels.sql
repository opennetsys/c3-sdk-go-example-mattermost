

--
-- Data for Name: publicchannels; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.publicchannels (id, deleteat, teamid, displayname, name, header, purpose) FROM stdin;
\.
