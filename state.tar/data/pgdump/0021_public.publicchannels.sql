

--
-- Data for Name: publicchannels; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.publicchannels (id, deleteat, teamid, displayname, name, header, purpose) FROM stdin;
0b05f1a24a02d56220bb12ed16	0	6eee2ef43121c3fcf6638a10e7	Off-Topic	off-topic		
3e841b6443a702d3e06b0492e9	0	6eee2ef43121c3fcf6638a10e7	Town Square	town-square		
\.
