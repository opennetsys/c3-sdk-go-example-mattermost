

--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.teams (id, createat, updateat, deleteat, displayname, name, description, email, type, companyname, alloweddomains, inviteid, allowopeninvite, lastteamiconupdate, schemeid) FROM stdin;
cb093fcd2fc817e5565430538e	37	37	0	foo	foo		ahanna@alumni.mines.edu	O			91a38123ecb3d85924afcbbf22	f	0	\N
\.
