

--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.teams (id, createat, updateat, deleteat, displayname, name, description, email, type, companyname, alloweddomains, inviteid, allowopeninvite, lastteamiconupdate, schemeid) FROM stdin;
6eee2ef43121c3fcf6638a10e7	29	29	0	public	public		ahanna@alumni.mines.edu	O			59cc8420f8f2904b1daf41ebff	f	0	\N
\.
