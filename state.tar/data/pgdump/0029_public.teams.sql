

--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.teams (id, createat, updateat, deleteat, displayname, name, description, email, type, companyname, alloweddomains, inviteid, allowopeninvite, lastteamiconupdate, schemeid) FROM stdin;
\.
