

--
-- Data for Name: licenses; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.licenses (id, createat, bytes) FROM stdin;
\.
