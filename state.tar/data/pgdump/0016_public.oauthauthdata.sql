

--
-- Data for Name: oauthauthdata; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.oauthauthdata (clientid, userid, code, expiresin, createat, redirecturi, state, scope) FROM stdin;
\.
