

--
-- Data for Name: reactions; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.reactions (userid, postid, emojiname, createat) FROM stdin;
\.
