

--
-- Data for Name: commandwebhooks; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.commandwebhooks (id, createat, commandid, userid, channelid, rootid, parentid, usecount) FROM stdin;
\.
