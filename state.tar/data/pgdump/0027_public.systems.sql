

--
-- Data for Name: systems; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.systems (name, value) FROM stdin;
AdvancedPermissionsMigrationComplete	true
AsymmetricSigningKey	{"ecdsa_key":{"curve":"P-256","x":73732167812337873268081446167896379823451468388639291990115353351372182986787,"y":64139504635358507572067119310931655359728824644288113650135678710393588948336,"d":115687085254710200964682848226857014783329576277878410221724834473140743372350}}
DiagnosticId	7myj1syuqid15fcqm3zdcwf4uh
EmojisPermissionsMigrationComplete	true
InstallationDate	1541463354624
LastSecurityTime	1541463355237
Version	5.4.0
migration_advanced_permissions_phase_2	true
\.
