

--
-- Data for Name: systems; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.systems (name, value) FROM stdin;
\.
