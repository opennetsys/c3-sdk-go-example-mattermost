

--
-- Data for Name: teammembers; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.teammembers (teamid, userid, roles, deleteat, schemeuser, schemeadmin) FROM stdin;
6eee2ef43121c3fcf6638a10e7	cb093fcd2fc817e5565430538e		0	t	t
\.
