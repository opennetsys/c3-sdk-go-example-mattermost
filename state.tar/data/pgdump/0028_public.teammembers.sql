

--
-- Data for Name: teammembers; Type: TABLE DATA; Schema: public; Owner: docker
--

COPY public.teammembers (teamid, userid, roles, deleteat, schemeuser, schemeadmin) FROM stdin;
\.
